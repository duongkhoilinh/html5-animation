$(document).ready(function () {

    var is_intro = false;

    if (is_intro) {

    }



});
